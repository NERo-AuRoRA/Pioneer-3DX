%%%% Pioneer P3-Dx: Rastreamento de Trajet�ria %%%%

clc, clear  
close all

% Close all the open connections
try
    fclose(instrfindall);
catch
end

%% Rotina para buscar pasta raiz - Look for root directory
addpath(genpath(pwd))

%% Classes initialization - Definindo o Rob�
% Criando uma vari�vel para representar o Rob�

p3dx(1) = Pioneer3DX;    % Pioneer (Rob�)

p3dx(1).pPar.a = 0.15; 
p3dx(1).pPar.alpha = 0*pi/3;

carretinha(1) = trailerNERO;  % Semi-trailer
carretinha(1).rGetSensorData(p3dx(1));

% Tempo de esperar para in�cio do experimento/simula��o
clc;
fprintf('\nIn�cio..............\n\n')
pause(1)


%% Definindo a Figura que ir� rodar a simula��o

f1 = figure('Name','Simula��o: Rob�tica M�vel (Pioneer P3-Dx)','NumberTitle','off');
f1.Position = [9 2 930 682];

figure(f1);

ax = gca;
ax.FontSize = 12;
xlabel({'$$x$$ [m]'},'FontSize',18,'FontWeight','bold','interpreter','latex');
ylabel({'$$y$$ [m]'},'FontSize',18,'FontWeight','bold','interpreter','latex');
zlabel({'$$z$$ [m]'},'FontSize',18,'FontWeight','bold','interpreter','latex');
axis equal
view(3)
view(45,30)
grid on
hold on
grid minor
light;
axis([-1.5 1.5 -1.5 1.5 0 1.5])
set(gca,'Box','on');


%% P.mCADplot();

t = tic;

p3dx(1).mCADplot;

carretinha(1).mCADplot('closed');
% carretinha(1).mCADplot('open');
carretinha(1).mCADcolor([0.4660 0.6740 0.1880]);

drawnow

disp([num2str(toc(t)) 's para 1� plot'])

pause()


%% Variables initialization
data = [];
Rastro.Xd = [];
Rastro.X = [];

%% Trajectory variables
a = 1;         % dist�ncia em x
b = 1;         % dist�ncia em y
w = 0.1;

nvoltas = 2;
tsim = 2*pi*nvoltas/w;

%% Simulation

% Temporiza��o
tap = 0.1;     % taxa de atualiza��o do pioneer
t = tic;
tc = tic;
tp = tic;

while toc(t) < tsim
    
    if toc(tc) > tap
        
        tc = tic;
        
      
        % Trajectory
        % Lemniscata (8')
        ta = toc(t);
        p3dx(1).pPos.Xd(1)  = a*sin(w*ta);       % posi��o x
        p3dx(1).pPos.Xd(2)  = b*sin(2*w*ta);     % posi��o y
        p3dx(1).pPos.Xd(7)  = a*w*cos(w*ta);     % velocidade em x
        p3dx(1).pPos.Xd(8)  = 2*b*w*cos(2*w*ta); % velocidade em y
        
        % Data aquisition
        p3dx(1).rGetSensorData;
        carretinha(1).rGetSensorData(p3dx(1));
        
        % salva vari�veis para plotar no gr�fico
        Rastro.Xd = [Rastro.Xd; p3dx(1).pPos.Xd(1:2)'];  % forma��o desejada
        Rastro.X  = [Rastro.X; p3dx(1).pPos.X(1:2)'];    % forma��o real
        
        % Control
        
        p3dx(1) = cKinematicController(p3dx(1));
        %P = cDynamicController(P);
        %P = cKinematicControllerExtended(P);

        data = [data; p3dx(1).pPos.Xd(1:2)' p3dx(1).pPos.X(1:2)' p3dx(1).pSC.Ud' p3dx(1).pSC.U' toc(t)];
        
        % Send control to robot
        p3dx(1).rSendControlSignals;
        

        % --------------------------------------------------------------- %


        % Desenha o rob�

        if toc(tp) > tap

            tp = tic;
            try
                delete(h);
                p3dx(1).mCADdel;
            catch
            end
            hold on
            p3dx(1).mCADplot;
            
            if toc(t) > tsim/2
                carretinha(1).mCADplot('open');
            else
                carretinha(1).mCADplot('closed');
            end

            h(1) = plot(Rastro.Xd(:,1),Rastro.Xd(:,2),'k');
            h(2) = plot(Rastro.X(:,1),Rastro.X(:,2),'g');
            axis([-1.5 1.5 -1.5 1.5 0 1])
            grid on
            hold off
            drawnow
        end   
    
    end


end

%%  Stop robot
% Zera velocidades do rob�
p3dx(1).pSC.Ud = [0 ; 0];
p3dx(1).rSendControlSignals;
% End of code xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

pause(2)

axis equal
set(gca,'Box','on')

figure()
subplot(211)
plot(data(:,end),data(:,1),'b',data(:,end),data(:,3),'r')
subplot(212)
plot(data(:,end),data(:,2),'b',data(:,end),data(:,4),'r')


