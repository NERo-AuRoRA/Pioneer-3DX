%%%% Pioneer P3-Dx: Rastreamento de Trajet�ria %%%%

clc, clear  
close all

% Close all the open connections
try
    fclose(instrfindall);
catch
end

%% Rotina para buscar pasta raiz - Look for root directory
addpath(genpath(pwd))

%% Classes initialization - Definindo o Rob�
% Criando uma vari�vel para representar o Rob�

p3dx(1) = Pioneer3DX;    % Pioneer (Rob�)

% p3dx(1).pPar.a = 0.15; 
% p3dx(1).pPar.alpha = 0*pi/3;



carretinha(1) = trailerNERO;  % Semi-trailer
carretinha(1).rGetSensorData(p3dx(1));

% Tempo de esperar para in�cio do experimento/simula��o
clc;
fprintf('\nIn�cio..............\n\n')
pause(1)


%% Definindo a Figura que ir� rodar a simula��o

f1 = figure('Name','Simula��o: Rob�tica M�vel (Pioneer P3-Dx)','NumberTitle','off');
f1.Position = [9 2 930 682];

figure(f1);

ax = gca;
ax.FontSize = 12;
xlabel({'$$x$$ [m]'},'FontSize',18,'FontWeight','bold','interpreter','latex');
ylabel({'$$y$$ [m]'},'FontSize',18,'FontWeight','bold','interpreter','latex');
zlabel({'$$z$$ [m]'},'FontSize',18,'FontWeight','bold','interpreter','latex');
axis equal
view(3)
view(45,30)
grid on
hold on
grid minor
light;
axis([-1.5 1.5 -1.5 1.5 0 1.5])
set(gca,'Box','on');


%% P.mCADplot();

t = tic;

p3dx(1).mCADplot;

carretinha(1).mCADplot('closed',p3dx(1));
% carretinha(1).mCADplot('open');
carretinha(1).mCADcolor([0.4660 0.6740 0.1880]);

drawnow

disp([num2str(toc(t)) 's para 1� plot'])


pause

%% Variables initialization
data = [];
Rastro.Xd = [];
Rastro.X = [];
Rastro.Xtrailer = [];

%% Trajectory variables
rX = 2;         % dist�ncia em x
rY = 2;         % dist�ncia em y
w = 0.1;

nvoltas = 2;
tsim = 2*pi*nvoltas/w;

%% Simulation ((Tem que arrumarm que arrumar))


% Cinem�tica estendida do pioneer
p3dx(1).pPar.a = 0;     % b = 0.2;
p3dx(1).pPar.b = 0.2;
p3dx(1).pPar.alpha = pi;


sat_v = 0.35;              % velocidade linear de satura��o [m/s]
sat_w = 120*pi/180;        % velocidade angular de satura��o [rad/s]


% Variaveis de Ganho
K1 = diag([0.8 0.8]);
K2 = diag([0.8 0.8]);




% Temporiza��o
tap = p3dx(1).pPar.Ts;     % taxa de atualiza��o do pioneer
t = tic;                   % Simula��o
tc = tic;                  % La�o de Controle
tp = tic;                  % Plot

while toc(t) < tsim
    
    if toc(tc) > tap
        
        tc = tic;
        
      
        % --- Desaired Trajectory -: Lemniscata (8') :-
        ta = toc(t);
        
        p3dx(1).pPos.Xd(1)  = rX*sin(w*ta);       % posi��o x
        p3dx(1).pPos.Xd(2)  = rY*sin(2*w*ta);     % posi��o y
        p3dx(1).pPos.Xd(7)  = rX*w*cos(w*ta);     % velocidade em x
        p3dx(1).pPos.Xd(8)  = 2*rY*w*cos(2*w*ta); % velocidade em y

        
        % --- Instantaneous Error 
        p3dx(1).pPos.Xtil = p3dx(1).pPos.Xd - p3dx(1).pPos.X;
        carretinha(1).pPos.Xtil = p3dx(1).pPos.Xd - carretinha(1).pPos.X;
        
        
        % --- Data aquisition
        %p3dx(1).rGetSensorData;
        
        %carretinha(1).rGetSensorData(p3dx(1));
        carretinha(1).pPos.X(1:2) = [p3dx(1).pPos.X(1) - carretinha(1).pPar.L0*cos(p3dx(1).pPos.X(6)) - (carretinha(1).pPar.L1 + p3dx(1).pPar.b)*cos(carretinha(1).pPos.X(6));
                                     p3dx(1).pPos.X(2) - carretinha(1).pPar.L0*sin(p3dx(1).pPos.X(6)) - (carretinha(1).pPar.L1 + p3dx(1).pPar.b)*sin(carretinha(1).pPos.X(6))];
                                 
        carretinha(1).pPos.Xc(1:2) = [p3dx(1).pPos.X(1) - carretinha(1).pPar.L0*cos(p3dx(1).pPos.X(6)) - carretinha(1).pPar.L1*cos(carretinha(1).pPos.X(6));
                                      p3dx(1).pPos.X(2) - carretinha(1).pPar.L0*sin(p3dx(1).pPos.X(6)) - carretinha(1).pPar.L1*sin(carretinha(1).pPos.X(6))];
        
        
        
        
        % --- Control
        U = p3dx(1).pPos.Xd(7:8) + K1*tanh(K2*p3dx(1).pPos.Xtil(7:8)) ;
        
        p3dx(1).pSC.Ud(1) = sqrt(U(1)^2 + U(2)^2);
        p3dx(1).pSC.Ud(2) = -((-U(1)/(p3dx(1).pPar.b*cos(p3dx(1).pPar.alpha)))*sin(p3dx(1).pPos.X(6)) ...
                              +(U(2)/(p3dx(1).pPar.b*cos(p3dx(1).pPar.alpha)))*cos(p3dx(1).pPos.X(6)));  
                          
        

                          
        K_inv_robo = [ cos(p3dx(1).pPos.X(6)), sin(p3dx(1).pPos.X(6)), 0; ...
                      -sin(p3dx(1).pPos.X(6)), cos(p3dx(1).pPos.X(6)), 0; ...
                                  0,                      0,           1];
                              
                              
        Ur = K_inv_robo*[U(1); U(2); p3dx(1).pSC.Ud(2)];
                 
        p3dx(1).pSC.Ud(1) = Ur(1);
        
        p3dx(1).pSC.Ud(2) = Ur(3); 
        
        
        % Satura��o:
        if abs(p3dx(1).pSC.Ud(1)) > sat_v
            p3dx(1).pSC.Ud(1) = sat_v*sign(p3dx(1).pSC.Ud(1));
        end
        
        if abs(p3dx(1).pSC.Ud(2)) > sat_w
            p3dx(1).pSC.Ud(2) = sat_w*sign(p3dx(1).pSC.Ud(2));
        end
        
        
        %p3dx(1) = cKinematicController(p3dx(1));
        %p3dx(1) = cDynamicController(P);
        %p3dx(1) = cKinematicControllerExtended(P);
        
        % Trailer:
        theta = p3dx(1).pPos.X(6) - carretinha(1).pPos.X(6);
        
        v1 = p3dx(1).pSC.Ud(1)*cos(theta)                       + (p3dx(1).pSC.Ud(2))*(carretinha(1).pPar.L0)*sin(theta);
        w1 = p3dx(1).pSC.Ud(1)*sin(theta)/carretinha(1).pPar.L1 - (p3dx(1).pSC.Ud(2))*(carretinha(1).pPar.L0)*cos(theta)/carretinha(1).pPar.L1;
        
        carretinha(1).pSC.Ud(1) = v1;
        carretinha(1).pSC.Ud(2) = w1;
        
        
        
        
        
        % --- Cinem�tica
        % Matriz de cinem�tica estendida do trailer
        carretinha(1).sKinematicModel(p3dx(1));
        
        p3dx(1).sKinematicModel();

        
        % Send control to robot
        p3dx(1).rSendControlSignals;
        carretinha(1).rSendControlSignals(p3dx(1));

        
        
        % --- salva vari�veis para plotar no gr�fico
        Rastro.Xd = [Rastro.Xd; p3dx(1).pPos.Xd(1:2)'];  % forma��o desejada
        Rastro.X  = [Rastro.X; p3dx(1).pPos.X(1:2)'];    % forma��o real
        Rastro.Xtrailer  = [Rastro.Xtrailer; carretinha(1).pPos.Xc(1:2)'];    % forma��o real

        data = [data; p3dx(1).pPos.Xd(:)' p3dx(1).pPos.X(:)' p3dx(1).pSC.Ud'...
                      carretinha(1).pPos.Xc' p3dx(1).pPos.Xtil' carretinha(1).pPos.Xtil'...
                      theta toc(t)];
        
        

        % --------------------------------------------------------------- %


        % Desenha o rob�

        if toc(tp) > tap

            tp = tic;
            try
                delete(h);
                p3dx(1).mCADdel;
            catch
            end
            hold on
            p3dx(1).mCADplot;
            
            if toc(t) > tsim/2
                carretinha(1).mCADplot('open',p3dx(1));
            else
                carretinha(1).mCADplot('closed',p3dx(1));
            end

            h(1) = plot(Rastro.Xd(:,1),Rastro.Xd(:,2),'k');
            h(2) = plot(Rastro.X(:,1),Rastro.X(:,2),'g');
            h(3) = plot(Rastro.Xtrailer(:,1),Rastro.Xtrailer(:,2),'r--');

%             axis([-1.5 1.5 -1.5 1.5 0 1])
            axis([-3 3 -3 3 0 1])

            grid on
            hold off
            drawnow
        end   
    
    end


end

%%  Stop robot
% Zera velocidades do rob�
p3dx(1).pSC.Ud = [0 ; 0];
p3dx(1).rSendControlSignals;
% End of code xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

pause(2)

axis equal
set(gca,'Box','on')

figure()
subplot(211)
plot(data(:,end),data(:,1),'b',data(:,end),data(:,13),'r')
subplot(212)
plot(data(:,end),data(:,2),'b',data(:,end),data(:,14),'r')


