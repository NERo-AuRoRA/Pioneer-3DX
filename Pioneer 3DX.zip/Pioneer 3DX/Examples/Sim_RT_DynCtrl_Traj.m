%% CONTROLE DE TRAJET�RIA PARA PIONEER
% utilizando o modelo din�mico parametrizado

clear
close all
clc
% Fecha todas poss�veis conex�es abertas
try
    fclose(instrfindall);
catch
end

%% Rotina para buscar pasta raiz
addpath(genpath(pwd))

%% Graphic Window definition
fig = figure(1);
axis([-3 3 -3 2])
axis equal

%% Classes initialization
% Robot
P = Pioneer3DX;
P.pPar.a = 0.1;

%% Connection with robot/simulator
% P.rConnect;           % rob� ou mobilesim
% shg                   % show graphic
% pause(7)
disp('Start..............')

%% Initial Position
% Xo = input('Digite a posi��o inicial do rob� ([x y z psi]): ');
Xo = [0 0 0 0];

P.rSetPose(Xo);         % define pose do rob�

%% Variables initialization
% Xa = P.pPos.X(1:6);    % postura anterior
data = [];
Rastro.Xd = [];
Rastro.X = [];

%% Trajectory variables
a = 1.5;         % dist�ncia em x
b = 1;         % dist�ncia em y

w = 0.1;

nvoltas = 2;
tsim = 2*pi*nvoltas/w;

%% Simulation

% Temporiza��o
tap = 0.1;     % taxa de atualiza��o do pioneer
t = tic;
tc = tic;
tp = tic;

while toc(t) < tsim
    
    if toc(tc) > tap
        
        tc = tic;
        
        % Trajectory
        % Lemniscata (8')
        ta = toc(t);
        P.pPos.Xd(1)  = a*sin(w*ta);       % posi��o x
        P.pPos.Xd(2)  = b*sin(2*w*ta);     % posi��o y
        P.pPos.Xd(7)  = a*w*cos(w*ta);     % velocidade em x
        P.pPos.Xd(8)  = 2*b*w*cos(2*w*ta); % velocidade em y
        
        % Data aquisition
        P.rGetSensorData;
        
        % salva vari�veis para plotar no gr�fico
        Rastro.Xd = [Rastro.Xd; P.pPos.Xd(1:2)'];  % forma��o desejada
        Rastro.X  = [Rastro.X; P.pPos.X(1:2)'];    % forma��o real
        
        % Control
        
        P = cDynamicController(P);
        data = [data; P.pSC.Ud' P.pSC.U'];
        
        % Send control to robot
        P.rSendControlSignals;
        
        
    end
    
    %% Desenha o rob�
    
    if toc(tp) > tap
        tp = tic;
        
        P.mCADdel
        
        try
            delete(h);
        end
        hold on
        % P.mCADplot(1,'k')
        P.mCADplot2D('r')
        h(1) = plot(Rastro.Xd(:,1),Rastro.Xd(:,2),'k');
        h(2) = plot(Rastro.X(:,1),Rastro.X(:,2),'g');
        axis([-3 3 -3 2])
        grid on
        hold off
        drawnow
    end
    
end

%%  Stop robot
% Zera velocidades do rob�
P.pSC.Ud = [0 ; 0];
P.rSendControlSignals;
% End of code xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
