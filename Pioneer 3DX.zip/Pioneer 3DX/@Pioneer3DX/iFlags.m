function iFlags(p3dx)

% Flags
p3dx.pFlag.Connected = 0;
p3dx.pFlag.JoyON = 0;
p3dx.pFlag.GPS = 0;
p3dx.pFlag.EmergencyStop = 0;
